from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(MsgsTypes)
admin.site.register(Msgs)
admin.site.register(MeesageType)
admin.site.register(Messages)

